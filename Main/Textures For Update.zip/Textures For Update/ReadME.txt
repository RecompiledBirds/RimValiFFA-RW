RimValiFFA/ is Rimvali-specific textures- eg. avail apparel, weapons, etc.

Things/ includes textures that avali use for vanilla rimworld and most other mods- eg. an avail wearing a parka.

This set of files is incomplete and only contains textures that should be updated.. for a full set of textures refer to https://github.com/RecompiledBirds/RimValiFFA-RW/tree/main/Main/Textures